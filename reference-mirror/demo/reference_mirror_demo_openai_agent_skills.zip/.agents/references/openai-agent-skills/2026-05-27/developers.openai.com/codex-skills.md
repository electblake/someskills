# Agent Skills – Codex | OpenAI Developers

Source: https://developers.openai.com/codex/skills
Captured: 2026-05-27

## Key captured content

OpenAI describes agent skills as a way to extend Codex with task-specific capabilities. A skill packages instructions, resources, and optional scripts so Codex can follow a workflow reliably. Skills build on the open Agent Skills standard.

Skills are the authoring format for reusable workflows. Plugins are the installable distribution unit for reusable skills and apps in Codex. Use skills to design the workflow, then package them as plugins when other developers should install them.

OpenAI states that skills are available in the Codex CLI, IDE extension, and Codex app.

Codex uses progressive disclosure: it starts with each skill's name, description, and file path, then loads the full SKILL.md only when it decides to use that skill. OpenAI notes the initial skills list is capped at roughly 2% of the model context window, or 8,000 characters when unknown.

A skill is a directory with a required SKILL.md file and optional scripts, references, assets, and agents/openai.yaml metadata.

Codex can activate skills explicitly, when directly invoked, or implicitly, when a task matches the skill description.

Codex reads skills from repository, user, admin, and system locations. Repository skill locations include `.agents/skills` under the current working directory, parent folders, and repository root. User skills may live at `$HOME/.agents/skills`; admin skills at `/etc/codex/skills`; bundled system skills are provided by OpenAI.

Optional `agents/openai.yaml` can configure UI metadata, invocation policy such as `allow_implicit_invocation`, and tool dependencies.

Best practices from the page include keeping each skill focused, preferring instructions over scripts unless deterministic behavior or external tooling is needed, writing imperative steps with explicit inputs and outputs, and testing prompts against skill descriptions.

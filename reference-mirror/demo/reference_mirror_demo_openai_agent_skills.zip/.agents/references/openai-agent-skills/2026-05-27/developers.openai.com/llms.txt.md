# developers.openai.com llms.txt

Source: https://developers.openai.com/llms.txt
Captured: 2026-05-27

The OpenAI Developers `llms.txt` identifies the site as the documentation hub for OpenAI API, Ads, Apps SDK, Codex, and Agentic Commerce. It links to product-specific documentation indexes and full documentation files, including Codex index and Codex full docs.

Relevant discovered page:

- Skills: https://developers.openai.com/api/docs/guides/tools-skills.md — described as uploading, managing, and attaching reusable skills to hosted environments.

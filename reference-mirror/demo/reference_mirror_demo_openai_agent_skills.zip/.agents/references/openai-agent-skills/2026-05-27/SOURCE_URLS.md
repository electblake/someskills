# Source URLs

## OpenAI official documentation

- https://developers.openai.com/codex/skills
- https://developers.openai.com/llms.txt

## Agent Skills standard documentation

- https://agentskills.io/llms.txt
- https://agentskills.io/home
- https://agentskills.io/specification
- https://agentskills.io/skill-creation/quickstart
- https://agentskills.io/skill-creation/best-practices

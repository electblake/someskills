# Reference Summary

- Reference Date: `2026-05-27`
- Topic: OpenAI Codex Agent Skills and the open Agent Skills standard
- Official Version: No single numbered version was identified in the captured pages. Treat this bundle as a date-stamped documentation snapshot.

## Official sources used

- OpenAI Codex Agent Skills documentation: `https://developers.openai.com/codex/skills`
- OpenAI Developers documentation index: `https://developers.openai.com/llms.txt`
- Agent Skills documentation index: `https://agentskills.io/llms.txt`
- Agent Skills overview, specification, quickstart, and best-practices pages from `agentskills.io`

## Key findings

- A skill is a directory containing a required `SKILL.md` file plus optional `scripts/`, `references/`, `assets/`, and other supporting files.
- `SKILL.md` requires YAML frontmatter with at least `name` and `description`, followed by Markdown instructions.
- Skill activation depends heavily on the description; descriptions should state both what the skill does and when to use it.
- Codex supports skills in the CLI, IDE extension, and Codex app.
- Codex uses progressive disclosure: initial context includes only name, description, and file path; full instructions load after activation.
- Skills author workflows; plugins distribute reusable skills and app integrations.
- Effective skills should be grounded in real project materials and improved through real execution traces.

## Compatibility notes

- OpenAI-specific configuration can use optional `agents/openai.yaml` for UI metadata, invocation policy, and tool dependencies.
- `allowed-tools` appears in the Agent Skills spec as experimental, with support varying by implementation.
- Repository-scoped Codex skills are discovered from `.agents/skills` locations; user-level skills may live under `$HOME/.agents/skills`.

## Runtime-specific note

- This bundle was assembled in `/mnt/data/reference_mirror_demo/.agents/references/openai-agent-skills/2026-05-27` because the added skill was available as a resource bundle rather than as a mounted filesystem directory in this session.

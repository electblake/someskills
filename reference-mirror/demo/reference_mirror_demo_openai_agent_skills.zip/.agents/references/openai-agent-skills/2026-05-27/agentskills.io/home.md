# Agent Skills Overview

Source: https://agentskills.io/home
Captured: 2026-05-27

Agent Skills are described as a lightweight, open format for extending AI agent capabilities with specialized knowledge and workflows. At core, a skill is a folder containing a SKILL.md file with metadata, including at least `name` and `description`, and instructions telling an agent how to perform a specific task.

Skills may bundle scripts, reference materials, templates, and other resources.

The docs describe progressive disclosure in three stages: discovery, where an agent loads names and descriptions; activation, where it reads the full SKILL.md when relevant; and execution, where it follows instructions and optionally runs bundled code or reads files.

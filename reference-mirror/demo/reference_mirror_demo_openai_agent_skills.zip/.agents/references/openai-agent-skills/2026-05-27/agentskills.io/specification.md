# Agent Skills Specification

Source: https://agentskills.io/specification
Captured: 2026-05-27

## Directory structure

A skill directory must contain at minimum a SKILL.md file. Optional directories include scripts, references, assets, and other files.

## SKILL.md format

SKILL.md must contain YAML frontmatter followed by Markdown content.

Required frontmatter fields:

- `name`: maximum 64 characters; lowercase letters, numbers, and hyphens only; must not start or end with a hyphen; must match the parent directory name.
- `description`: maximum 1024 characters; non-empty; describes what the skill does and when to use it.

Optional fields include `license`, `compatibility`, `metadata`, and experimental `allowed-tools`.

The body contains skill instructions. Recommended content includes step-by-step instructions, examples of inputs and outputs, and common edge cases.

## Progressive disclosure

The spec recommends structuring skills so metadata is small, full instructions are under 5,000 tokens, and resources load only when required. It recommends keeping main SKILL.md content under 500 lines and moving detailed reference material to separate files.

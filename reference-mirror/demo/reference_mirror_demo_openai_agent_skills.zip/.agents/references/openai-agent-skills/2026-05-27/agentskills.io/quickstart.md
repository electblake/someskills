# Quickstart - Agent Skills

Source: https://agentskills.io/skill-creation/quickstart
Captured: 2026-05-27

The quickstart shows creating a skill under `.agents/skills/roll-dice/SKILL.md` with YAML frontmatter containing `name` and `description`, followed by executable instructions. It explains that the name is the short identifier, the description helps the agent decide whether to activate the skill, and the body contains instructions the agent follows after activation.

The page explains the runtime flow as discovery, activation, and execution.

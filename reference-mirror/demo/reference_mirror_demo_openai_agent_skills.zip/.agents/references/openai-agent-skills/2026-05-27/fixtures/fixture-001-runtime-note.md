# Runtime note

This is a demonstration fixture, not an official source. In this ChatGPT environment, the reference-mirror bundled scripts were exposed through resource APIs rather than a mounted skill filesystem, so the bundle was assembled in `/mnt/data/reference_mirror_demo` while preserving the skill's target layout and source-separation rules.

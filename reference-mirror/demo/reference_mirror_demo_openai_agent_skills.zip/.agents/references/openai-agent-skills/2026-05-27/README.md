# openai-agent-skills

- Topic: `openai-agent-skills`
- Capture Date: `2026-05-27`
- Scope: Current official OpenAI Codex Agent Skills documentation plus the open Agent Skills standard pages needed to explain format, progressive disclosure, and authoring requirements.
- Example user prompt: "Mirror the current official documentation for OpenAI Codex Agent Skills and the open Agent Skills spec into `.agents/references/`, then summarize the key facts for a team that may author reusable skills."

This bundle was created as an end-to-end demonstration of the `reference-mirror` skill. It keeps official-source captures under domain folders and does not modify plugin, deployment, or runtime files.

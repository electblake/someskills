# Reference Index

## Bundle files

- `README.md`: bundle purpose, capture date, and example user prompt
- `SOURCE_URLS.md`: verified official URLs used in this snapshot
- `REFERENCE_SUMMARY.md`: curated findings, dates, and compatibility notes
- `REFERENCE_INDEX.md`: this navigation hub
- `fixtures/fixture-001-runtime-note.md`: runtime-specific demonstration note, clearly separated from official sources

## Mirrored official content

### developers.openai.com

- `developers.openai.com/codex-skills.md`: OpenAI Codex Agent Skills documentation summary
- `developers.openai.com/llms.txt.md`: OpenAI Developers documentation index excerpt

### agentskills.io

- `agentskills.io/llms.txt.md`: Agent Skills documentation index
- `agentskills.io/home.md`: Agent Skills overview
- `agentskills.io/specification.md`: format requirements and validation-related constraints
- `agentskills.io/quickstart.md`: authoring quickstart and activation flow
- `agentskills.io/best-practices.md`: creator guidance and iteration practices
